export class Flora{
    poster:string;
    name:string;
    price:number;
    qty:number;
    constructor(fposter?,fname?,fprice?,fqty?){
        this.poster=fposter;
        this.name=fname;
        this.price=fprice;
        this.qty=fqty;
    }
}