export class Employee
{
 id:number;
 name:string;
 age:number;
 favStatus:boolean;
  constructor(id?,name?,age?,fav?)
   {
   this.id=id;
   this.name=name;
   this.age=age;
   this.favStatus=fav;
    }
}
